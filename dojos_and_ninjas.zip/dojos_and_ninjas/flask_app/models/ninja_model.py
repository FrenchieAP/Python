from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import DATABASE
class Ninja:
    def __init__( self , data ):
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.age = data['age']
        self.dojo_id = data['dojo_id']

    @classmethod
    def add_ninja(cls, data):
        query = "INSERT INTO ninjas(first_name, last_name, age, dojo_id) VALUES(%(fname)s, %(lname)s, %(age)s, %(dojo_id)s);"
        return connectToMySQL('dojos_and_ninjas').query_db(query, data)

    @classmethod
    def get_all_ninjas(cls):
        query = "SELECT * FROM ninjas;"
        results = connectToMySQL('dojos_and_ninjas').query_db(query)
        ninjas = []
        for ninja in results:
            ninjas.append( cls(ninja) )
        return ninjas

    @classmethod
    def get_ninjas_from_dojo(cls, data):
        query = "SELECT * FROM ninjas LEFT JOIN dojos ON dojos.id = ninjas.dojo_id WHERE dojos.id = %(id)s"
        results = connectToMySQL(DATABASE).query_db(query, data)
        all_ninjas = []
        for row_from_db in results:
            ninja_instance = cls(row_from_db)
            all_ninjas.append(ninja_instance)
        return all_ninjas