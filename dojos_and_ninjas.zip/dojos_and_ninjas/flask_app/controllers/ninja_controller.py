from flask_app import app
from flask import render_template,redirect,request,session,flash
from flask_app.models.ninja_model import Ninja
from flask_app.models.dojo_model import Dojo

@app.route("/addninja")
def add_ninja():
    dojo_list = Dojo.get_all()
    return render_template("addninja.html", dojo_list = dojo_list)

@app.route('/create_ninja', methods=["POST"])
def create_ninja():

    Ninja.add_ninja(request.form)
    return redirect("/dojos")

# @app.route('/ninjas')
# def all_ninjas():
#     return render_template("ninjas.html")

@app.route("/this_dojo/<int:id>")
def this_dojo(id):
    data = {
        "id" : id
    }
    ninja_list = Ninja.get_ninjas_from_dojo(data)
    this_dojo = Dojo.get_one(data)
    return render_template("this_dojo.html", ninja_list = ninja_list, this_dojo = this_dojo)
