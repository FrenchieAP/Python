from flask_app import app
from flask import render_template,redirect,request,session,flash
from flask_app.models.dojo_model import Dojo

@app.route("/dojos")
def index():
    dojo_list = Dojo.get_all()
    return render_template("dojos.html", dojo_list = dojo_list)    

@app.route('/add_dojo', methods=["POST"])
def add_dojo():
    data = {
        "name": request.form["name"],
    }
    Dojo.add_dojo(data)
    return redirect("/dojos")

# @app.route('/delete_dojo', methods=["POST"])
# def delete_dojo():
#     Dojo.delete_dojo()
#     return redirect('/')


    

