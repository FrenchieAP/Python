from flask import Flask, render_template, request, redirect
# import the class from friend.py
from users import User
app = Flask(__name__)
@app.route("/")
def index():
    user_list = User.get_all()
    return render_template("index.html", user_list = user_list)

@app.route("/create")
def create():
    return render_template("create.html")
@app.route('/allusers', methods = ["POST"])
def allusers():
    data = {
        "fname": request.form["fname"],
        "lname" : request.form["lname"],
        "email" : request.form["email"]
    }
    User.get_all(cls)
    return redirect('/')

@app.route('/add_user', methods=["POST"])
def add_user():
    return redirect("/create")

@app.route('/create_user', methods=["POST"])
def create_user():
    data = {
        "fname": request.form["fname"],
        "lname" : request.form["lname"],
        "email" : request.form["email"]
    }
    User.add(data)
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)