from flask_app import app
from flask import render_template,redirect,request,session,flash
from flask_app.models.recipes_model import Recipe
from flask_app.models.users_model import User

@app.route("/add_recipe")
def add_recipe():
    return render_template("add_recipe.html")

@app.route('/create_recipe', methods=["POST"])
def create_recipe():
    print(request.form)
    if 'user_id' not in session:
        return redirect('/')
    if not Recipe.validator(request.form):
        return redirect("/add_recipe")
    data = {
        **request.form, 
        "user_id" : session['user_id']
    }
    Recipe.add_recipe(data)
    return redirect("/all_recipes")

@app.route('/all_recipes')
def dash():
    if not "user_id" in session:
        return redirect('/')
    data = {
        "id" : session['user_id']
    }
    new_id = User.get_one(data)
    recipe_list = Recipe.get_all_recipes()
    return render_template("all_recipes.html", new_id = new_id, recipe_list = recipe_list)

@app.route('/edit_recipe/<int:id>', methods=["POST"])
def edit_recipe(id):
    if not Recipe.validator(request.form):
        return redirect(f'/update_recipe/{id}')
    data = {
        **request.form,
        'id' : id
    }
    Recipe.edit_recipe(data)
    return redirect("/all_recipes")

@app.route('/update_recipe/<int:id>')
def update_recipe(id):
    this_recipe = Recipe.get_by_id({"id":id})
    return render_template("edit_recipe.html", this_recipe = this_recipe)

@app.route('/delete_recipe/<int:id>')
def delete_recipe(id):
    Recipe.delete({"id":id})
    return redirect('/all_recipes')

@app.route('/recipe/<int:id>')
def one_recipe(id):
    data = {
        "id": id
    }
    this_recipe = Recipe.get_by_id({"id":id})
    return render_template("one_recipe.html", this_recipe = this_recipe)

