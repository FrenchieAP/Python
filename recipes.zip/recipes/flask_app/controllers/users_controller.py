from flask_app import app
from flask import render_template,redirect,request,session,flash
from flask_app.models.users_model import User
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)

@app.route('/')
def landing():
    return render_template('index.html')

# @app.route('/all_recipes/<int:user_id>')
# def this_user(data, user_id):
#     data = {
#         "user_id": user_id
#     }
#     user_list = User.get_one(data)
#     return render_template("all_recipes.html", user_list = user_list)

@app.route('/users/register', methods=['POST'])
def reg_user():
    if not User.validator(request.form):
        return redirect('/')
    hash_browns = bcrypt.generate_password_hash(request.form['password'])
    data = {
        **request.form,
        'password': hash_browns
    }
    new_id = User.create(data)
    session['user_id'] = new_id
    return redirect('/all_recipes') 

@app.route ('/users/login', methods=['POST'])
def log_user():
    data = {
        'email' : request.form['email']
    }
    user_in_db = User.get_by_email(data)
    if not user_in_db:
        flash("Invalid credentials", "log")
        return redirect ('/')
    if not bcrypt.check_password_hash(user_in_db.password, request.form['password']):
        flash("Invalid Credentials **", "log")
        return redirect('/')
    session['user_id'] = user_in_db.id
    return redirect('/all_recipes')

@app.route('/users/logout')
def log_out_user():
    del session['user_id']
    return redirect('/')
