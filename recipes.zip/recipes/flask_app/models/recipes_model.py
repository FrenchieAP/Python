from flask_app.config.mysqlconnection import connectToMySQL
from flask_app import DATABASE
from flask_app.models import users_model
from flask import flash

class Recipe:
    def __init__( self , data ):
        self.id = data['id']
        self.name = data['name']
        self.description = data['description']
        self.instructions = data['instructions']
        self.under_thirty = data['under_thirty']
        self.date_cooked = data['date_cooked']
        self.user_id = data['user_id']

    @classmethod
    def add_recipe(cls, data):
        print(data)
        query = "INSERT INTO recipes(name, description, instructions, under_thirty, date_cooked, user_id) VALUES(%(name)s, %(description)s, %(instructions)s, %(under_thirty)s, %(date_cooked)s, %(user_id)s)"
        return connectToMySQL(DATABASE).query_db(query, data)

    @classmethod
    def get_all_recipes(cls):
        query = "SELECT * FROM recipes JOIN users ON recipes.user_id = users.id;"
        results = connectToMySQL('recipes_schema').query_db(query)
        recipes = []
        for row in results: 
            this_recipe = cls(row)
            user_data = {
            **row
            }
            this_user = users_model.User(user_data)
            this_recipe.chef = this_user
            recipes.append(this_recipe)
        return recipes

    @classmethod
    def edit_recipe(cls,data):
        query = "UPDATE recipes SET name = %(name)s, description = %(description)s, instructions = %(instructions)s, under_thirty = %(under_thirty)s, date_cooked = %(date_cooked)s WHERE id = %(id)s;"
        return connectToMySQL('recipes_schema').query_db(query, data)

    @classmethod
    def get_by_id(cls,data):
        query = "SELECT * FROM recipes JOIN users ON recipes.user_id = users.id WHERE recipes.id = %(id)s;"
        results = connectToMySQL('recipes_schema').query_db(query, data)
        row = results[0]
        this_recipe = cls(row)
        user_data = {
            **row
        }
        this_user = users_model.User(user_data)
        this_recipe.chef = this_user
        return this_recipe

    @classmethod
    def delete(cls,data):
        query = "DELETE FROM recipes WHERE id = %(id)s;"
        return connectToMySQL('recipes_schema').query_db(query, data)

    @staticmethod
    def validator(potential_recipe):
        is_valid = True
        if len(potential_recipe['name']) <= 1:
            flash("Name is not long enough", "reg")
            is_valid = False
        if len(potential_recipe['description']) <= 5:
            flash("Description is not long enough", "reg")
            is_valid = False
        if len(potential_recipe['instructions']) <= 1:
            flash("Instructions are not long enough", "reg")
            is_valid = False
        if len(potential_recipe['date_cooked'])  <= 1:
            flash("You need a date", "reg")
            is_valid = False
        return is_valid