from flask_app import app
from flask import render_template,redirect,request,session,flash
from flask_app.models.user import User


@app.route("/")
def index():
    user_list = User.get_all()
    return render_template("index.html", user_list = user_list)

@app.route("/create")
def create():
    return render_template("create.html")
    
@app.route('/allusers', methods = ["POST"])
def allusers():
    data = {
        "fname": request.form["fname"],
        "lname" : request.form["lname"],
        "email" : request.form["email"]
    }
    User.get_all(cls)
    return redirect('/')

@app.route('/add_user', methods=["POST"])
def add_user():
    return redirect("/create")

@app.route('/user/<int:id>')
def user(id):
    data = {
        "id": id
    }
    this_user = User.get_one(data)
    return render_template("user.html", this_user = this_user)

@app.route('/edit/<int:id>')
def edit_user(id):
    data = {
        "id": id
    }
    this_user = User.get_one(data)
    return render_template("edit.html", this_user = this_user)

@app.route('/delete/<int:id>')
def delete_user(id):
    data = {
        "id": id
    }
    User.delete_one(data)
    return redirect("/")

@app.route('/edit_user/<int:id>', methods=["POST"])
def edit_this_user(id):
    data = {
        "id" : id,
        "fname": request.form["fname"],
        "lname" : request.form["lname"],
        "email" : request.form["email"]
    }
    User.edit_user(data)
    return redirect("/")


@app.route('/create_user', methods=["POST"])
def create_user():
    data = {
        "fname": request.form["fname"],
        "lname" : request.form["lname"],
        "email" : request.form["email"]
    }
    User.add(data)
    return redirect("/")