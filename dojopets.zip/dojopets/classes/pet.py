class Pet:

    def __init__( self , name, type, tricks, health, energy ):
        self.name = "Chompy McChompster"
        self.type = "Piranha"
        self.tricks = 10
        self.health = 10
        self.energy = 10

        def sleep( self ):
            self.energy += 1
            print(f'{self.name} is taking a nap. Zzz Zzz')
            
        def eat ( self ):
            self.health += 1
            print(f"Ninja tosses some live rodents and goat offal into {self.name}'s tank. {self.name} is thriving.")

        def play ( self ):
            self.energy -= 2
            print(f'{self.name} lets out a blood-curdling shriek. REEEEEEEAAAAAAAAAHHHHHHHHH D:<')

        def noise ( self ):
            self.health -= 2