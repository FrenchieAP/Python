class Ninja: 

    def __init__( self , name ):
        self.name = "Ninja McNinjapants"
        self.pet = "Piranha"
        self.treats = 10
        self.petfood = 10

    def bathe( self, pet ):
        print(f'{pet.name} is always bathing because it is a fish.')

    def feed ( self, pet ):
        pet.health += 1
        self.petfood -= 1
        print(f"Ninja tosses some live rodents and goat offal into {self.name}'s tank. {self.name} is thriving.")

    def play ( self, pet ):
        self.treats -= 1
        print(f'{self.name} plays with his favorite Piranha.')

