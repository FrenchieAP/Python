from classes.pet import Pet
from classes.ninja import Ninja

pet = Pet("Chompy McChompster")

while (pet.health > 0):
    print("There's your pet, Ninja! Will you \n 1) Feed it \n 2) Bathe it \n 3) Play with it \n 4) Put it to sleep")
    response = input(">>>")
    if response == "1":
        pet.eat(pet)    
    else: 
        pet.sleep(pet)
    # elif response == "2":
    #     pet.bathe(pet)
    # elif response == "3":
    #     pet.play(pet)
    # elif response == "4":
    
